"""
Bike sharing prediction model, made in IE with ♥
"""

__version__ = "0.1.0"
